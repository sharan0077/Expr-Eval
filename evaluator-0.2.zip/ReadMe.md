Expression Evaluator:

Release 0.1 :

-> Will take expression that contains two operands and an operator and returns the result.
-> The operands should be of type int.
-> The supported operators are as follows : +,-,*,/.
 Example :
    ExprEval_GS.sh "3 + 4"
    result : 7
